# Aligned Muse/SAM dataset training handoff

Base: public main 73f1c6a. Local source commit: ef56fd8.

Apply from your existing repository root, using the real extracted patch path:

```bash
git apply --check /absolute/path/to/aligned-dataset-training.patch
git apply /absolute/path/to/aligned-dataset-training.patch
```

Then read docs/ALIGNED_DATASET_TRAINING.md. It contains the cache, training and
resume commands for profile khagendrakhatri365. Use the authorized profile and
workspace that owns your existing data and weights. No credentials are included.

The code keeps the current model architecture. It adds a persistent resumable
NF4 feature cache, shuffled batches across all aligned TRAIN episodes,
effective batch 64 by default, optional warm-start from the aligned 7,500-update
weights, periodic development evaluation and complete training state saves.
Validation episodes are excluded from optimizer batches. New phase update counts
and example presentations are logged separately from the single-episode source.

CPU verification: 52 tests pass; compilation, Modal CLI help/import and patch
application checks pass. Actual multi-episode GPU cache/train/rollout execution
has NOT been performed by the assistant. Existing single-episode results do not
validate the new batched path or demonstrate manipulation success.

No Modal job was launched. Cache extraction and training are PAID jobs with
explicit runtime limits; the timers are not invoice-level spending caps. The
commands do not automatically launch rollouts or additional paid functions.
A partial cache can be resumed; training waits for a complete validated cache.

Source files are included under payload/ for inspection, with SHA256SUMS.txt.
