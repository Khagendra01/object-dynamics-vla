# Quantized Muse preflight: missing executable files

This handoff supplies the three missing code files. The code-only patch is
checked against public main at 7ac2a88 and deliberately does not modify the
QUANTIZED_MUSE_NEXT_RUN.md file already in your checkout.

## Apply from your existing repository root

Unzip this download somewhere accessible, then run:

```bash
git apply --check /absolute/path/to/quantized-muse-preflight-code.patch
git apply /absolute/path/to/quantized-muse-preflight-code.patch
python -m modal run -m scripts.modal_quantized_muse_preflight --profile khagendrakhatri365
```

Use the actual extracted patch path. The first command checks all changes before
applying. Do not copy the payload over unrelated local edits if the check fails.
The payload/ directory contains the exact source files for inspection.

Existing Modal credentials in profile khagendrakhatri365 are expected to work.
The earlier lack of credentials applied only to the assistant execution session,
not your PC. No new login or credential transfer is requested.

## Run and artifacts

Defaults: one H200, four real milk-training RGB frames with existing SAM history,
at most 20 batch-one updates of a freshly initialized official SmolVLA expert,
then a finite-action sampling check. Muse is frozen NF4 via Transformers,
with BF16 computation. No robot-pretrained expert or teacher is loaded. The
existing learned prefix adapter is reused; this is not an exact reproduction of
the official SmolVLM conditioning or a robot-control success claim.

The remote function has a 900-second timeout and a 120-second training-loop cap.
At the quoted H200 rate, 900 seconds of GPU time is about $1.14; CPU/RAM, startup,
builds and other resources are separate. Existing checkpoint and data paths are
required; they are not downloaded implicitly in the GPU job.

The default output directory is:
/data/eval/quantized_muse_preflight_v1/

Retrieve it with:

```bash
python -m modal volume get object-dynamics-vla-data /eval/quantized_muse_preflight_v1 ./outputs/quantized_muse_preflight_v1 --profile khagendrakhatri365
```

Return report.json, plus the first full exception if a failure occurs. A new
--name is required if the default directory already exists. Success writes
preflight_weights.pt as well as report.json; no simulator action is executed.

## Verification performed before delivery

- 47 CPU tests passed on the source checkout, including three quantized-loading
  contract tests with a fake loader. These do not verify real NF4 GPU execution.
- Python compilation and Modal CLI import/help passed.
- This code-only patch applies cleanly to public main at 7ac2a88.
- Each payload file was checked byte-for-byte against the locally committed
  source 6438b33; the remote GPU run remains to be performed on your PC.
